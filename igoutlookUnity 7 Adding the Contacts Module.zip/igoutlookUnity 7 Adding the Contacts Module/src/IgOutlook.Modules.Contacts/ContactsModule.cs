﻿using IgOutlook.Infrastructure;
using IgOutlook.Infrastructure.Prism;
using IgOutlook.Modules.Contacts.Menus;
using IgOutlook.Modules.Contacts.Views;
using IGOutlook.Infrastructure;
using IGOutlook.Infrastructure.Prism;
using Microsoft.Practices.Unity;

using IGOutlook.Infrastructure.Prism;
using Prism.Regions;

namespace IgOutlook.Modules.Contacts
{
    public class ContactsModule : ModuleBase
    {
        public ContactsModule(IUnityContainer container, IRegionManager regionManager)
            : base(container, regionManager)
        {

        }

        public override void RegisterTypes()
        {
            Container.RegisterTypeForNavigation<ContactsView>();
        }

        public override void ResolveOutlookGroup()
        {
            RegionManager.Regions[RegionNames.OutlookBarGroupRegion].Add(Container.Resolve<ContactsGroup>());
        }
    }
}
