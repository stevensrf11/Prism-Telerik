﻿namespace IgOutlook.Modules.Contacts.Menus
{
    /// <summary>
    /// Interaction logic for HomeTab.xaml
    /// </summary>
    public partial class HomeTab 
    {
        public HomeTab()
        {
            InitializeComponent();
        }
    }
}
