﻿
using System.Windows.Controls;

using IgOutlook.Infrastructure;
using IgOutlook.Modules.Contacts.Menus;
using Prism.Regions;

namespace IgOutlook.Modules.Contacts.Views
{
    /// <summary>
    /// Interaction logic for ContactsView.xaml
    /// </summary>
    [RibbonTab(typeof(HomeTab))]
    public partial class ContactsView 
    {
        public ContactsView(IRegionManager regionManager)
                  : base(regionManager)
        {
            InitializeComponent();
        }
    }
}
/*
    [RibbonTab(typeof(HomeTab))]
    public partial class ContactsView :  IgOutlook.Infrastructure.ViewBase
    {
        public ContactsView(IRegionManager regionManager)
            : base (regionManager)
        {
            InitializeComponent();
        }
    }
 * */
