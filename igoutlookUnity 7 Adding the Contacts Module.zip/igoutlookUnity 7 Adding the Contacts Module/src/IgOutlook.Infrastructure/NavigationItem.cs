﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace IgOutlook.Infrastructure
{
    public class NavigationItem: INavigationItem
    {
        public string Caption { get; set; }
        public bool IsExpanded { get; set; }
        public string NavigationPath { get; set; }
        public ObservableCollection<NavigationItem> Items { get; set; }

        public NavigationItem()
        {
            IsExpanded = true;
            Items = new ObservableCollection<NavigationItem>();
        }
    }
}
