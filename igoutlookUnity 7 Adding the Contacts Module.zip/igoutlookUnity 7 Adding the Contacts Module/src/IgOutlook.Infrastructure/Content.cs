﻿using System.Collections.ObjectModel;
using Prism.Commands;
using Prism.Mvvm;

namespace IgOutlook.Infrastructure
{
    public class Content : BindableBase
    {
        public Content()
        {
            Children = new ObservableCollection<Content>();
        }
        public string Type { get; set; }
        public DelegateCommand MyCommand { get; set; }
        public string Text { get; set; }

        public ObservableCollection<Content> Children { get; set; }
    }
}
