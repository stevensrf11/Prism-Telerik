﻿using System.Windows;
using System.Windows.Input;
using Telerik.Windows.Controls;

namespace IgOutlook.Infrastructure.Prism
{
    public class XamDataTreeItemSelected
    {
        private static readonly DependencyProperty SelectedCommandBehaviorProperty = 
            DependencyProperty.RegisterAttached("SelectedCommandBehavior", 
                typeof(XamDataTreeCommandBehavior), 
                typeof(XamDataTreeItemSelected), null);

        public static readonly DependencyProperty CommandProperty =
            DependencyProperty.RegisterAttached("Command", 
                typeof(ICommand), 
                typeof(XamDataTreeItemSelected), 
                new PropertyMetadata(OnSetCommandCallback));
        public static ICommand GetCommand(RadTreeView menuItem)
        {
            return menuItem.GetValue(CommandProperty) as ICommand;
        }
        public static void SetCommand(RadTreeView menuItem, ICommand command)
        {
            menuItem.SetValue(CommandProperty, command);
        }

        private static void OnSetCommandCallback(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            RadTreeView menuItem = dependencyObject as RadTreeView;
            if (menuItem != null)
            {
                XamDataTreeCommandBehavior behavior = GetOrCreateBehavior(menuItem);
                behavior.Command = e.NewValue as ICommand;
            }
        }

        public static readonly DependencyProperty CommandParameterProperty =
            DependencyProperty.RegisterAttached("CommandParameter",
                typeof(object), typeof(XamDataTreeItemSelected),
                new PropertyMetadata(OnSetCommandParameterCallback));
        public static object GetCommandParameter(RadTreeView menuItem)
        {
            return menuItem.GetValue(CommandParameterProperty);
        }
        public static void SetCommandParameter(RadTreeView menuItem, object parameter)
        {
            menuItem.SetValue(CommandParameterProperty, parameter);
        }

        private static void OnSetCommandParameterCallback(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            RadTreeView menuItem = dependencyObject as RadTreeView;
            if (menuItem != null)
            {
                XamDataTreeCommandBehavior behavior = GetOrCreateBehavior(menuItem);
                behavior.CommandParameter = e.NewValue;
            }
        }

        private static XamDataTreeCommandBehavior GetOrCreateBehavior(RadTreeView menuItem)
        {
            XamDataTreeCommandBehavior behavior = menuItem.GetValue(SelectedCommandBehaviorProperty) as XamDataTreeCommandBehavior;
            if (behavior == null)
            {
                behavior = new XamDataTreeCommandBehavior(menuItem);
                menuItem.SetValue(SelectedCommandBehaviorProperty, behavior);
            }

            return behavior;
        }
    }
}
