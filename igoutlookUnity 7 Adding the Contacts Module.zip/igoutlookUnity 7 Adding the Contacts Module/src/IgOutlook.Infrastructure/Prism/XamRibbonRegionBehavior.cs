﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using IGOutlook.Infrastructure;
using Microsoft.Practices.Unity;
using Prism.Regions;
using Telerik.Windows.Controls;

namespace IgOutlook.Infrastructure.Prism
{
    public class XamRibbonRegionBehavior : RegionBehavior
    {
        /// <summary>
        /// The key of this behavior.
        /// </summary>
        public const String BehaviorKey = "XamRibbonRegionBehavior";
        private IUnityContainer _container;
        public XamRibbonRegionBehavior(IUnityContainer container)
        {
            _container = container;
        }
        /// <summary>
        ///  Executed whenever behavior is attached to region
        /// </summary>
        protected override void OnAttach()
        {
            if (Region.Name == RegionNames.ContentRegion)
                Region.ActiveViews.CollectionChanged += ActiveViews_CollectionChanged;
        }

        void ActiveViews_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            // Whenever new view is added and injected into content region
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                // loop through all new items
                bool isFirst = true;
                foreach (var newView in e.NewItems)
                {
                    //make sure we are dealing with the right type of view
                    var view = newView as IViewBase;
                    if (view == null)
                        continue;
                    // See if any ribbon tabs create, not want to recreate ribbontabs again
                    //if we already have ribbons no need on checking again
                    if (view.RibbonTabs.Count > 0)
                        continue;

                    // Make sure this ribbon tab has correct attribute
                    //loop through all the ribbon tab attributes and create them for the view
                    foreach (var atr in GetCustomAttributes<RibbonTabAttribute>(newView.GetType()))
                    {
                        // Create Instance of  tabitem, Note IRibbonTabItem
                        // ribbonTabItem = (IRibbonTabItem)Activator.CreateInstance(atr.Type);
                     var   ribbonTabItem = (IRibbonTabItem)Activator.CreateInstance(atr.Type, new object[] { _container.Resolve<HomeTabViewModel>() }) ;

                        // set ribbontabitem view  viewmodel to  same viewmodel of our view
                        // setting  datacontext of ribbontabitem view to that of view  
                       // ribbonTabItem.ViewModel = view.ViewModel;

                        // put ribbontabitem  in collection which is in viewbase
                        //- public IList<IRibbonTabItem> RibbonTabs { get; private set; }
                        view.RibbonTabs.Add(ribbonTabItem);

                        //?? logic to preselect first tab in collection
                        ribbonTabItem.IsSelected = isFirst;

                        if (isFirst)
                            isFirst = false;
                    }
                }
            }
        }

        IEnumerable<T> GetCustomAttributes<T>(Type type)
        {
            return type.GetCustomAttributes(typeof(T), true).OfType<T>();
        }
    }
}
