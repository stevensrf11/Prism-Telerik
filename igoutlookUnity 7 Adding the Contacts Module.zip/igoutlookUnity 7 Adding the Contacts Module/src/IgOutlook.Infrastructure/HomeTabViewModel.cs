﻿using System;
using System.Collections.ObjectModel;
using Prism.Commands;
using Prism.Mvvm;

namespace IgOutlook.Infrastructure
{
    public class HomeTabViewModel : BindableBase
    {
        public HomeTabViewModel()
        {
            Header = "Module 1";
            IsSelected = true;
            Groups = new ObservableCollection<Group>();

            Group group1 = new Group { Header = "Group 1" };
            Content button = new Content { Type = "RadButton", Text = "RibbonButton", MyCommand = new DelegateCommand(RadButtonCommand) };
            group1.Items.Add(button);
            Content splitButton = new Content { Type = "RadSplitButton", Text = "RibbonSplitButton", MyCommand = new DelegateCommand(RadSplitButtonCommand) };
            for (int i = 0; i < 5; i++)
            {
                splitButton.Children.Add(new Content { Text = String.Format("Option {0}", i) });
            }
            group1.Items.Add(splitButton);

            Groups.Add(group1);
        }
        public string Header { get; set; }
        public ObservableCollection<Group> Groups { get; set; }

        private bool isSelected;
        public bool IsSelected
        {
            get
            {
                return isSelected;
            }
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    this.SetProperty(ref this.isSelected, value);

                }
            }
        }

        private void RadButtonCommand()
        {
            // RadWindow.Alert("RadButton");
        }
        private void RadSplitButtonCommand()
        {
            //RadWindow.Alert("RadSplitButton");
        }
    }
}
