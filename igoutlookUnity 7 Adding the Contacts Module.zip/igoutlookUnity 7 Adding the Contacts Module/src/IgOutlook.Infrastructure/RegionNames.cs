﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IGOutlook.Infrastructure
{
    public static class RegionNames
    {
        public const string RibbonTabRegion = "RibbonTabRegion";
        public const string OutlookBarGroupRegion = "OutlookBarGroupRegion";
        public const string ContentRegion = "ContentRegion";

    }
}
