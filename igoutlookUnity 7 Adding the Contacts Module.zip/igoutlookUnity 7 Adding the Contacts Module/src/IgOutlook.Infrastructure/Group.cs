﻿using System.Collections.ObjectModel;

namespace IgOutlook.Infrastructure
{
    public class Group
    {
        public Group()
        {
            Items = new ObservableCollection<Content>();
        }
        public string Header { get; set; }
        public ObservableCollection<Content> Items { get; set; }
    }
}
