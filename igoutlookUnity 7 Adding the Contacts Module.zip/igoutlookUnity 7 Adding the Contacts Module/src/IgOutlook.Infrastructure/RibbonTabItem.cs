﻿using Telerik.Windows.Controls;

namespace IgOutlook.Infrastructure
{

    /// <summary>
    ///  RadRibbonTab has IsSelected property defined and it is exposed through interface IRibbonTabItem
    /// </summary>
    public class RibbonTabItem : RadRibbonTab, IRibbonTabItem

    {
        public IViewModel ViewModel
        {
            get
            {
                return (IViewModel)DataContext;
            }
            set
            {
                DataContext = value;
            }
        }
    }
}
