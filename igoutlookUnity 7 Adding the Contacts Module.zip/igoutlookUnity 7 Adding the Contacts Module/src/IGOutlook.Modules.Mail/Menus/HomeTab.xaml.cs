﻿
using IgOutlook.Infrastructure;

namespace IgOutlook.Modules.Mail.Menus
{
    /// <summary>
    /// Interaction logic for HomeTab.xaml
    /// </summary>
    public partial class HomeTab
    {
        public HomeTab(HomeTabViewModel vomeTabViewModel)
        {
            InitializeComponent();
            DataContext = vomeTabViewModel;
        }
    }
}
