﻿using IgOutlook.Infrastructure;
using IgOutlook.Modules.Mail.Menus;
using Telerik.Windows.Controls;

namespace IGOutlook.Modules.Mail.Menus
{
    /// <summary>
    /// Interaction logic for MailGroup.xaml
    /// </summary>
    //[Export]
    public partial class MailGroup : RadOutlookBarItem,IOutlookBarGroup
    {
        public MailGroup(MailGroupViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
        public string DefaultNavigationPath
        {
            get
            {
                var item = _xamDataTree.SelectedItem ;
                if (item != null)
                {
                    return ( item as INavigationItem).NavigationPath;
                }
                else
                {
                    return typeof (IgOutlook.Modules.Mail.Views.DefaultView).FullName;
                }
            }
        }
    }
}
