﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;
using Prism.Modularity;
using Prism.Regions;

namespace IGOutlook.Infrastructure.Prism
{
    /// <summary>
    /// Register Types and views
    /// </summary>
    public abstract class ModuleBase :IModule
    {
        protected IUnityContainer Container { get; private set; }
        protected IRegionManager RegionManager { get; private set; }
        // container for mef is CompositionContainer
       // [ImportingConstructor]
        public ModuleBase(IUnityContainer container, IRegionManager regionManager)
        {
            RegionManager = regionManager;
            Container = container;
        }
        public void Initialize()
        {
            RegisterTypes();
            ResolveOutlookGroup();
        }

        public abstract void RegisterTypes();
        public abstract void ResolveOutlookGroup();
    
    }
}
