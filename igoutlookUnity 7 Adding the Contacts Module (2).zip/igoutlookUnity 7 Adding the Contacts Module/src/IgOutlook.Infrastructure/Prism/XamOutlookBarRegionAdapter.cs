﻿using System.Collections.Specialized;
using Prism.Regions;
using Telerik.Windows.Controls;


//using Telerik.Windows.Controls.WindowBase;
namespace IGOutlook.Infrastructure.Prism
{
    // [Export( typeof(XamOutlookBarRegionAdapter))] XamOutlookBarRegionAdapter
    public class XamOutlookBarRegionAdapter : RegionAdapterBase<RadOutlookBar>
    {
        //[ImportingConstructor]
        public XamOutlookBarRegionAdapter(IRegionBehaviorFactory regionBehaviorFactory)
			: base(regionBehaviorFactory)
		{ }

        // Adapting control to accept veiws
        protected override void Adapt(IRegion region, RadOutlookBar regionTarget)
        {
            region.ActiveViews.CollectionChanged += ((x, y) =>
            {
                switch (y.Action)
                {
                    case NotifyCollectionChangedAction.Add:
                    {
                        foreach (var goupitem in y.NewItems)
                        {
                                regionTarget.Items.Add(goupitem);
                                if (regionTarget.Items[0] == goupitem)
                                    regionTarget.SelectedItem = goupitem;
                            }
                    }
                        break;
                    case NotifyCollectionChangedAction.Remove:
                    {
                        foreach (var goupitem in y.NewItems)
                        {
                            regionTarget.Items.Remove(goupitem);
                        }
                    }
                        break;
                }
            });

        }

        /// <summary>
        /// Ask what kind of region is this will just contain content control or multiple views
        /// </summary>
        /// <returns></returns>
        protected override IRegion CreateRegion()
        {
            return new AllActiveRegion();
        }
    }
}
