﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IgOutlook.Infrastructure
{
    public interface IViewModel
    {
        string Title { get; set; }
    }
}
