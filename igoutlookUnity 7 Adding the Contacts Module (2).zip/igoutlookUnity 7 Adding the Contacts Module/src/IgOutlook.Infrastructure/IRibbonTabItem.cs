﻿
namespace IgOutlook.Infrastructure
{
    public interface IRibbonTabItem
    {
        /// <summary>
        /// Make sure that the view model the data context for the ribbon is sane as the view being injected in the content region
        /// </summary>
        IViewModel ViewModel { get; set; }

        /// <summary>
        /// selected ribbon tab item when going to new view
        /// </summary>
        bool IsSelected { get; set; }
    }
}
