﻿using IgOutlook.Infrastructure;
using IgOutlook.Modules.Mail.Menus;
//using Microsoft.Practices.Prism.Regions;
//using Microsoft.Practices.Prism.Events;
using Prism.Events;
using Prism.Regions;

namespace IgOutlook.Modules.Mail.Views
{
    //[RibbonTab(typeof(HomeTab))]
    //[RibbonTab(typeof(HomeTab))]
    //[RibbonTab(typeof(HomeTab))]

    [RibbonTab(typeof(HomeTab))]
    public partial class MailView
    {
        public MailView(IMailViewViewModel viewModel, IRegionManager regionManager, IEventAggregator eventAggregator)
            : base (viewModel, regionManager, eventAggregator)
        {
            InitializeComponent();
        }
    }
}
